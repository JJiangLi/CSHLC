%--------------------------------����˵��----------------------------------%
% dirGauMeanI  ��N�η����˹�˲���Ľ��
% edgI         �������ʹ�����ı�Ե���
% C            ���ָ�ͼ�������
% W            �����������ڴ�С
%-------------------------------------------------------------------------%
function [finalI] = ctrSmooth(dirGauMeanI,edgI,C,W)
        
    fr=(W-1)/2;                                %�뾶
    [row,col]=size(dirGauMeanI);
    
    sigma=2;
    GauTemp=fspecial('gaussian',[W, W],sigma); %��ȡ��˹�˲��� 
    
    smoothMap=zeros(row,col);
    for i=1:row
        for j=1:col
            if edgI(i,j)==0                    %����õ㲻�Ǳ�Ե
                X0= max(1,i-fr);
                Xn= min(row,i+fr);
                Y0= max(1,j-fr);
                Yn= min(col,j+fr);
                edgCut=edgI(X0:Xn,Y0:Yn);      %����ȡ����Ե��ȡͼ��
                ICut=dirGauMeanI(X0:Xn,Y0:Yn); %����ȡ�������˹�˲���ͼ��
                %��ȡ��˹�˲�����
                tempCut=GauTemp(X0-i+1+fr:Xn-i+1+fr,Y0-j+1+fr:Yn-j+1+fr);      
                %ʵ�������������˲�
                [smoothVal]=smoothUsingEdg(ICut,edgCut,tempCut, C,i-X0+1,j-Y0+1); 
                smoothMap(i,j)=smoothVal;
            end
        end
    end
    
    smoothMap(smoothMap==0)=Inf;               %�ָ���Ե��
    [finalI]=transEdgToLabel(smoothMap,dirGauMeanI);

end

function [resMap]=transEdgToLabel(edgLabelMap,Img)

    adj=[-1,0;0,-1;1,0;0,1];
    [row,col]=size(edgLabelMap);
    resMap=edgLabelMap;

    [outerEdgMap,hasEdg]=findOuterEdg(edgLabelMap);
    while(hasEdg)                             %�����ڱ�Եʱ
        for i=1:row
            for j=1:col
                if outerEdgMap(i,j)==1        %���õ�Ϊ��Եʱ
                   mindis=Inf;
                   mink=1;
                   for k=1:length(adj)
                        xx=i+adj(k,1);
                        yy=j+adj(k,2);
                        if xx>=1 && xx<=row && yy>=1 && yy <=col && edgLabelMap(xx,yy)~=Inf
                            d=abs(Img(xx,yy)-Img(i,j));
                            if d<mindis
                               mindis=d;
                               mink=k;
                            end
                        end
                   end
                   resMap(i,j)=edgLabelMap(i+adj(mink,1),j+adj(mink,2));
                end
            end
        end  
        edgLabelMap=resMap;
        [outerEdgMap,hasEdg]=findOuterEdg(edgLabelMap);  
    end 
end

function [outerEdgMap,hasEdg]=findOuterEdg(edgLabelMap)

    adj=[-1,0;0,-1;1,0;0,1;1,1;1,-1;-1,1;-1,-1];
    [row,col]=size(edgLabelMap);
    outerEdgMap=zeros(row,col);
    
    hasEdg=0;                                %��־λ
    for i=1:row
        for j=1:col
            if edgLabelMap(i,j)==Inf         %����õ��Ǳ�Ե�������8�����������
                for k=1:length(adj)
                   xx=i+adj(k,1);
                   yy=j+adj(k,2);
                   if xx>=1 && xx<=row && yy>=1 && yy <=col && edgLabelMap(xx,yy)~=Inf
                      outerEdgMap(i,j)=1;    %����õ�������û��������Ե����õ�ֵΪ1
                      if hasEdg==0
                         hasEdg=1; 
                         break;
                      end
                   end
                end
            end
        end
    end

end
    
function [smoothVal]=smoothUsingEdg(ICut,edgCut,GauTemp,C,i,j)

    adj=[-1,0;0,-1;1,0;0,1];  %4����
    [row,col]=size(edgCut);   
    roadMap=zeros(row,col);
    
    Xarray=zeros(row*col,1); 
    Yarray=zeros(row*col,1);
    AftPoint=1;                  
    BefPoint=1;                  
    Xarray(AftPoint)=i;      
    Yarray(AftPoint)=j;

    while BefPoint <= AftPoint
        x=Xarray(BefPoint);
        y=Yarray(BefPoint);
        BefPoint=BefPoint+1;
        roadMap(x,y)=1;      
        for k=1:length(adj)
           xx=x+adj(k,1);
           yy=y+adj(k,2);
           if xx>=1 && xx<=row && yy>=1 && yy <=col && edgCut(xx,yy)~=Inf
               if (roadMap(xx,yy)==0) 
                   AftPoint=AftPoint+1;
                   Xarray(AftPoint)=xx;
                   Yarray(AftPoint)=yy;
                   roadMap(xx,yy)=2;                                   
               end
           end
        end
    end
    GauTemp(roadMap==0)=0;    %���ص��Ǳ�Ե���Ӧ�ĸ�˹�˲�λ��ֵΪ0�������˲�
    res=(ICut.*GauTemp);
    smoothVal = sum(res(:))/sum(GauTemp(:));

end
